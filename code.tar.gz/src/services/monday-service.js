import initMondayClient from "monday-sdk-js";
const monday = initMondayClient();

export async function fetchItemName(id) {
  try {
    const query = `query{
      items(ids: [${id}]){
        name
      }
    }`;
    const response = await monday.api(query);
    return response;
  } catch (error) {
    console.error(error);
    return "Could not locate item id";
  }
}

// Send a notification to a user. (target is the id of the thing updating about)
export async function sendNotifications(userIds, target, text) {
  const monday = initMondayClient();
  monday.setToken(process.env.MONDAY_API_TOKEN);
  try {
    for (const userId of userIds) {
      const query = `
      mutation($userId: ID!, $targetId: ID!, $text: String!, $targetType: NotificationTargetType!) {
      create_notification (user_id: $userId, target_id: $targetId, text: $text, target_type: $targetType) {
      text
      }
    }
      `;
      const variables = {
        targetId: target,
        userId: userId,
        text: text,
        targetType: "Project",
      };
      const res = await monday.api(query, { variables });
      console.dir({ res }, { depth: null });
    }
    return {
      message: "Success sending notifications",
      status: 200,
      data: "Success",
    };
  } catch (error) {
    console.error(error);
    return {
      message: "Error sending notifications",
      status: 500,
      data: error,
    };
  }
}

// Fins usernames for users
export const findUsernames = async (userIds) => {
  // Array needs to be passed to this query, sometimes try to find multiple also
  if (!Array.isArray(userIds)) {
    userIds = [userIds];
  }
  try {
    const query = `query {
        users (ids: ${JSON.stringify(userIds)}) {
          id
          name
        }
      }
      `;
    const response = await monday.api(query);
    console.dir({ response }, { depth: null });
    return {
      message: "Successfully fetched usernames.",
      status: 200,
      data: response,
    };
  } catch (error) {
    console.error(error);
    return {
      message: "Error finding usernames.",
      status: 500,
      data: error,
    };
  }
};
