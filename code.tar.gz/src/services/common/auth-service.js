import { UsersTable } from "../../schema/schemas.js";
import { createEntry, findById, updateField } from "../crud.js";
import crypto from "crypto";

import initMondayClient from "monday-sdk-js";
const monday = initMondayClient();

export const fetchAuthToken = async (userId, uri) => {
  const sessionState = crypto.randomBytes(20).toString("hex");
  try {
    // Fetch users api key
    const authRes = await findById(UsersTable, UsersTable.id, userId);
    if (authRes.status === 500) {
      return {
        ...authRes,
        message: authRes.message || "Error fetching user.",
      };

      // If no user found, create it
    } else if (authRes.status === 404) {
      const createUserRes = await createEntry(UsersTable, {
        id: parseInt(userId),
      });
      if (createUserRes.status !== 201) {
        return createUserRes;
      }

      //   Send user to oAuth to get api key.
      // Use sessionState for validating callback

      return {
        message: "Redirect to OAuth",
        status: 201,
        data: {
          userId: userId,
          uri: uri,
          state: sessionState,
        },
      };
    } else if (
      authRes?.data &&
      Array.isArray(authRes.data) &&
      authRes.data.length >= 1
    ) {
      if (authRes.data.accessKey) {
        return {
          status: 200,
          message: "Access key successfully found.",
          data: authRes.data.accessKey,
        };
      } else {
        return {
          status: 404,
          message: "Redirect to OAuth",
          data: {
            userId: userId,
            uri: uri,
            state: sessionState,
          },
        };
      }
    }
  } catch (error) {
    console.error(error);
    return {
      message: error.message || "Error fetching user api key.",
      status: error.status || 500,
      data: error,
    };
  }
};

export const fetchSaveAccessKey = async (code, userId) => {
  try {
    const token = await monday.oauthToken(
      code,
      process.env.CLIENT_ID,
      process.env.CLIENT_SECRET
    );
    console.log({ token });
    if (!token) {
      return { message: "Invalid request.", status: 500, data: [] };
    }
    const saveTokenRes = await updateField(
      UsersTable,
      UsersTable.id,
      UsersTable.accessKey,
      { accessKey: token },
      userId
    );
    if (saveTokenRes.status !== 200) {
      return saveTokenRes;
    }
    return {
      message: "Access token saved successfully.",
      status: 200,
      data: saveTokenRes.data || [],
    };
  } catch (error) {
    console.error(error);
    return {
      message: "Invalid request.",
      status: 500,
      data: error,
    };
  }
};
