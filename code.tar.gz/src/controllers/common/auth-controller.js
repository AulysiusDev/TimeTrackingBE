import {
  fetchAuthToken,
  fetchSaveAccessKey,
} from "../../services/common/auth-service.js";
import querystring from "querystring";
import jwt from "jsonwebtoken";

export const getAuthKey = async (req, res) => {
  console.log("Recieved");
  const { redirect_uri, sessionToken } = req.body;

  const token = jwt.verify(sessionToken, process.env.CLIENT_SECRET);
  const { user_id, account_id } = token.dat;
  console.log({ user_id });

  // if (!userId) {
  //   return res.status(400).json({ message: "No user id provided." });
  // }
  try {
    const state = jwt.sign(
      {
        userId: user_id,
        accountId: account_id,
        backToUrl: redirect_uri,
      },
      process.env.CLIENT_SECRET
    );
    const authTokenRes = await fetchAuthToken(user_id, redirect_uri);
    if (authTokenRes.message === "Redirect to OAuth") {
      console.log("redirect");
      // res.status(404).json({ message: "Send to OAuth" });
      res.redirect(
        "https://auth.monday.com/oauth2/authorize?client_id=04f9b452097fb800832d0ccb74175590"
      );
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message:
        error.message ||
        authTokenRes.message ||
        "Error redirecting user to OAuth",
      data: error,
    });
  }
};

export const saveAuthKey = async (req, res) => {
  const { code, state } = req.query;
  console.log({ code });
  const token = jwt.verify(state, process.env.CLIENT_SECRET);
  console.log({ callbackToken: token });

  // if (sessionState !== req.session?.state || !code || !userId || !uri) {
  //   return res.status(403).json({ message: "Invalid request." });
  // }
  // const fetchSaveAccessKeyRes = await fetchSaveAccessKey(code, userId);
  // if (
  //   fetchSaveAccessKeyRes.status !== 200 ||
  //   fetchSaveAccessKeyRes.status !== 201
  // ) {
  //   return res.status(fetchSaveAccessKeyRes.status).json(fetchSaveAccessKeyRes);
  // } else {
  //   res.redirect(uri);
  // }
};
